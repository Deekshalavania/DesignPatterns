package com.epam.java.homeTaskOnVariable;

public class ProgranOnIntVar {

	public static void main(String[] args) {
		int danielApples=3;
		int amberApples=2;
		int total=danielApples+amberApples;
		
		System.out.println("Total Apples that Daniel and Amber have together are " +total);
	}

}
