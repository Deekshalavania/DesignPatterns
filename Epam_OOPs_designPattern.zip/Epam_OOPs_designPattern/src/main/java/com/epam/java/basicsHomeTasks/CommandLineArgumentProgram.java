package com.epam.java.basicsHomeTasks;

public class CommandLineArgumentProgram {

	public static void main(String[] args) {

		System.out.println("Hello "+args[0]);  

	}

}
