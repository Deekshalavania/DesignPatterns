package com.epam.java.constructHomeTask;

public class LotteryTicket {

	public static int ticket(int a, int b, int c)
	{
		if(a == b && b == c)
		{
			if(a == 2)
				return 10;
			return 5;
		}
		if(a != b && a !=c)
			return 1;
		return 0;
	}
	public static void main(String[] args) {

		System.out.println(LotteryTicket.ticket(2,2,0));
	}

}
