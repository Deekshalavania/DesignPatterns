package com.epam.java.designPattern;

public class BillPughSingletonClass {
	
	private static BillPughSingletonClass instance;
	
	private BillPughSingletonClass()
	{
		
	}
	
	private static class BillPugh{
		private static BillPughSingletonClass instance = new BillPughSingletonClass();
	}
	
	public static BillPughSingletonClass getInstance() {
		return BillPugh.instance;
	}

}
