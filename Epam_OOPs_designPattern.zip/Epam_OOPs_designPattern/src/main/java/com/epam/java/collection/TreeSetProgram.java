package com.epam.java.collection;

import java.util.ArrayList;
import java.util.TreeSet;

import javax.swing.text.html.HTMLDocument.Iterator;

public class TreeSetProgram {

	public static void main(String[] args) {
        TreeSet<Integer> numSet = new TreeSet<Integer>(); 
        numSet.add(30); 
        numSet.add(10); 
        ArrayList<Integer> myList = new ArrayList<Integer>();
        myList.add(15);
        myList.add(25);
        myList.add(35);
        numSet.addAll(myList);
        java.util.Iterator<Integer> iterator = numSet.iterator(); 
        System.out.print("Tree set contents: "); 
        while (iterator.hasNext()) 
            System.out.print(iterator.next() + " "); 
        System.out.println(); 
        System.out.println("ceiling(25):" + numSet.ceiling(25));
        System.out.println("floor(25):" + numSet.floor(25));
        System.out.println("TreeSet contains(15):" + numSet.contains(15));
         if (numSet.isEmpty()) 
            System.out.print("Tree Set is empty."); 
        else
            System.out.println("Tree Set size: " + numSet.size()); 
   
          System.out.println("TreeSet First element: " + numSet.first()); 
          System.out.println("TreeSet Last element: " + numSet.last()); 
        if (numSet.remove(30)) 
            System.out.println("Element 30 removed from TreeSet"); 
        else
            System.out.println("Element 30 doesn't exist!"); 
   
        System.out.print("TreeSet after remove (): "); 
        iterator = numSet.iterator(); 
        while (iterator.hasNext()) 
            System.out.print(iterator.next() + " "); 
        System.out.println(); 
        System.out.println("TreeSet size after remove (): " + numSet.size()); 
        System.out.println("Headset : " + numSet.headSet(35));
        numSet.clear(); 
        System.out.println("Tree Set size after clear (): " + numSet.size());
	}

}
