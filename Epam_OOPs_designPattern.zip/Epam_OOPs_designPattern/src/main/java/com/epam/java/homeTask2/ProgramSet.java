package com.epam.java.homeTask2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

public class ProgramSet {

	public static void main(String[] args) {
		
		long start1=System.nanoTime();

		HashSet<String> hset = new HashSet<String>();
		
		hset.add("Hi");
		hset.add("Bye");
		hset.add("Hello");
		hset.add("Hola");
		hset.add("hey"); 
		hset.remove("Hola");
        System.out.println("HashSet contains: ");

        for (String str : hset) {
            System.out.println(str);
        }
        
		long end1=System.nanoTime();
		System.out.println("Time taken by hashSet set for adding inserting, accessing, removing "+(end1-start1));
		
        long start=System.nanoTime();
		List<String> list = new ArrayList<String>(hset);
        Collections.sort(list);
        long end=System.nanoTime();
        
        System.out.println("Time taken by HashSet to sort elements is "+(end-start));
        
		long start2=System.nanoTime();
		TreeSet<String> t = new TreeSet<String>();

        t.add("Hi");
        t.add("Bye");
        t.add("Hello");
        t.add("Hola");
        t.add("Hey"); 
        t.remove("hola");
        
        long s=System.nanoTime();
		TreeSet<String> t1 = new TreeSet<String>();

        long e=System.nanoTime();
        
	     System.out.println("Time taken by TreeSet to sort elements is "+(e-s));

		 System.out.println("TreeSet contains: ");

	        for (String str : t) {
	            System.out.println(str);
	        }
	        
			long end2=System.nanoTime();

		System.out.println("Time taken by Tree set for adding inserting, accessing, removing "+(end2-start2));
		
		
		long start3=System.nanoTime();
        long end3=System.nanoTime();
        
        System.out.println("Time taken by HashSet to sort elements is "+(end-start));
		
	}

}
