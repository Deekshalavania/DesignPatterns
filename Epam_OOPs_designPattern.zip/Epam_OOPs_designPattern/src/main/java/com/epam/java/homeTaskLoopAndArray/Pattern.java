package com.epam.java.homeTaskLoopAndArray;

import java.util.Scanner;

public class Pattern {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		 int rows = 5, number =0;
		 int x=sc.nextInt();

		    for(int i = 1; i <= rows; i++) {

		      for(int j = 1; j <= i; j++) {
		        System.out.print(x*number + " ");
		        ++number;
		      }

		      System.out.println();
		    }
	}
}
