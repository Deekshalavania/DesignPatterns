package com.epam.java.constructHomeTask;

public class SumLimitProgram {

	public static int sumLimit(int a, int b)
	{
		int aLength = fun(a);
		int sum = a + b;
		if(aLength == fun(sum))
			return sum;
		return a;
	}
	
	public static int fun(int num)
	{
		int count = 0;
		while(num != 0)
		{
			num /= 10;
			count++;
		}	
		return count;
	}
	public static void main(String[] args) {
		System.out.println(sumLimit(2, 3) );
		System.out.println(sumLimit(2, 3) );
		System.out.println(sumLimit(8, 1));
	}

}
