package com.epam.java.collection;

import java.util.HashMap;
import java.util.Map;

public class HashMapProgram {
	  public static void main(String args[])
	  {
	    HashMap<Integer,String> hashMap = new HashMap<Integer,String>();

	    hashMap.put(1, "Rank 1");
	    hashMap.put(2, "Rank 2");
	    hashMap.put(3, "Rank 3");
	    hashMap.put(4, "Rank 4");
	    for(Map.Entry<Integer, String> entry : hashMap.entrySet()) {
	      System.out.println(entry.getKey()+" : "+entry.getValue());
	    }
	    hashMap.replace(1, "Rank One");
	    System.out.println(hashMap);
	    hashMap.replace(1, "Rank One", "First");
	    System.out.println(hashMap);
	  }
	}

