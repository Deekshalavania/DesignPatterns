package com.epam.java.designPattern;

public class LazySingletonClass {
	
	private LazySingletonClass() {
	}
	
	private static LazySingletonClass instance;
	public static LazySingletonClass getInstance()
	{
	if(instance ==null)
	{
	 synchronized(LazySingletonClass.class)
	 {
		 if(instance==null)
		 {
			 instance=new LazySingletonClass();
		 }
	 }
	}
	return instance;
	}

}
