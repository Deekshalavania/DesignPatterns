package com.epam.java.homeTaskLoopAndArray;


	class CustomException extends Exception{
		CustomException (String msg)
		{
			super(msg);
		}
	}

	public class CustomExceptionProgram {

		public static void main(String[] args) {

	     String str1="Epam is a good company";
	     try {
	     if(str1.length()<100) {
	    	 throw new CustomException("Length is less than 100");
	     }
	     }
	     catch(CustomException e){
	    	 System.out.println("Exception caught");
	    	 e.printStackTrace();
	    	 System.out.println(e.getMessage());
	    	 
	     }
}
	}
