package com.epam.java.constructHomeTask;

public class NumberSix {

	public boolean love6(int a, int b) {
	  if (a == 6 || b == 6)
	    return true;

	  int sum = a+b;
	  int diff = Math.abs(a-b);
	if (sum == 6 || diff == 6)
	    return true;
	  else
	    return false;
	}

	public static void main(String args[])
	{
		NumberSix ns=new NumberSix();
		System.out.println(ns.love6(6, 7));
		System.out.println(ns.love6(3, 3));
		System.out.println(ns.love6(12, 6));
		System.out.println(ns.love6(8, 61));



	}
	
}
