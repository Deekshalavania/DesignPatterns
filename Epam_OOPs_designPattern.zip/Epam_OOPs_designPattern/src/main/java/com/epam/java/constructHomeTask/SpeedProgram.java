package com.epam.java.constructHomeTask;

public class SpeedProgram {
	public static int caughtSpeeding(int speed, boolean isBirthday) {

		  if (!(isBirthday)) {
		    if (speed <= 60)
		      return 0;
		    if (speed > 60 && speed <= 80)
		      return 1;
		    else
		      return 2;
		  } else if (speed <=65)
		      return 0;
		    else if (speed > 65 && speed <= 85)
		      return 1;
		    else
		      return 2;
		}

	public static void main(String[] args) {
		int result1=SpeedProgram.caughtSpeeding(65, false);
		int result2=SpeedProgram.caughtSpeeding(60, true);
		
		System.out.println(result1);
		System.out.println(result2);

		

	}

}
