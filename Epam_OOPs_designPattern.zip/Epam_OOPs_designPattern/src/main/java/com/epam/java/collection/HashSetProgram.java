package com.epam.java.collection;

import java.util.HashSet;

public class HashSetProgram {

	public static void main(String[] args) {

		HashSet<Integer> numbers = new HashSet<Integer>();
        numbers.add(2);
        numbers.add(5);
        numbers.add(6);
        System.out.println("HashSet: " + numbers);

        boolean value1 = numbers.remove(5);
        System.out.println("Is 5 removed? " + value1);

        boolean value2 = numbers.removeAll(numbers);
        System.out.println("Are all elements removed? " + value2);
	}

}
