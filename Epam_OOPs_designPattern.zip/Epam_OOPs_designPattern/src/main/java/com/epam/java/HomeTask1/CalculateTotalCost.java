package com.epam.java.HomeTask1;

import java.util.Arrays;
import java.util.List;

public class  CalculateTotalCost  {

	
	  public static double totalCost(List list ) {
	
		  	double total=0;
			for(int i=0;i<list.size();i++) {
				Sweet s=(Sweet) list.get(i);
				total+=s.getsweetCost();
			}
			return total;
	
}
}
