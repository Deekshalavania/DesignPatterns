package com.epam.java.constructHomeTask;

public class MaxCounterProgram {

	
	public static int maxBlock(String str) {
		  int maxCounter=1;
		  int counter=1;
		  if(str.length()==0)
		  {
		    return 0;
		  }  
		  for(int i=0;i<str.length()-1;i++)
		  {
		    if(str.substring(i,i+1).equals(str.substring(i+1,i+2)))
		    {
		      counter++;

		    }   
		    if(counter>maxCounter)
		    {
		      maxCounter=counter;
		      counter=0;
		    }            
		  }  
		  return maxCounter;          
		}
	public static void main(String[] args) {

		
		System.out.println(maxBlock("Hello"));
	}

}
