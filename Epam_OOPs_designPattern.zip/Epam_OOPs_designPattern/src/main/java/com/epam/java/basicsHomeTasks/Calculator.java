package com.epam.java.basicsHomeTasks;

public class Calculator {

	
	
	public static void main(String[] args) {

	        int a = Integer.parseInt(args[0]);
	        int b = Integer.parseInt(args[1]);

	        String sign = args[2];
	        int z;
	        
	        if (sign.equals("+")) {
	            z = a+b;
	        } else if (sign.equals("-")){
	            z = a-b;
	        } else if (sign.equals("*")){
	            z = a*b;
	        } else if (sign.equals("/")){
	            z = a/b;
	        } else if(sign.equals("%")) {
	        	z=(a+b)*100/2;
	        }else{
	             throw new java.lang.Error("signerator not recognized");
	        }
	        System.out.println(z);
	    }	
		
	}


