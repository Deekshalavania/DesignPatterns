package com.epam.java.arrayStringPrograms;

import java.util.Scanner;

public class MissingElementArray {
	
	public static void main(String args[])
	{
		int n=100;
		int array[]=new int[n];
		int expectedSum, missingNumber, sum=0;
		
		Scanner sc=new Scanner(System.in);

		for(int i=0;i<n;i++)
		{
			array[i]=sc.nextInt();
			sum+=array[i];
		}
		
		expectedSum=(n*(n-1))/2;
		missingNumber=sum-expectedSum;
		
		System.out.println("Missing Number is "+ missingNumber);
		
		
	}

}
