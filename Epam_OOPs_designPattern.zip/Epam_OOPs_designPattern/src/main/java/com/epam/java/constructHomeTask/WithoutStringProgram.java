package com.epam.java.constructHomeTask;

public class WithoutStringProgram {
	public String withoutString(String base, String remove) {
		  String result = "";
		  int baseLength = base.length();
		  int removeLength = remove.length();
		  String lowerCase = base.toLowerCase();
		  String lowerCaseRemove = remove.toLowerCase();
		  for (int i = 0; i < baseLength; i++) {
			  
		    if (i <= baseLength - removeLength) {
		      String var1 = lowerCase.substring(i,i+removeLength);
		      if (!var1.equals(lowerCaseRemove))
		        result += base.substring(i,i+1);
		      else {
		        i += removeLength-1;
		      }
		    }
		
		    else {
		      String var2 = lowerCase.substring(i,i+1);
		      if (!var2.equals(lowerCaseRemove))
		        result += base.substring(i,i+1);
	
		    }}
		  return result;
		}
	public static void main(String[] args) {
		

		WithoutStringProgram ws=new WithoutStringProgram();
		System.out.println(ws.withoutString("Hello there", "llo"));
		System.out.println(ws.withoutString("Hello there", "e"));
		System.out.println(ws.withoutString("Hello there", "x"));
		
	}

}
