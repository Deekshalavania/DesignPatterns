package com.epam.java.homeTaskLoopAndArray;

 class SingletonClass {
	private SingletonClass(){}
	private static class BillPugh{
		private static SingletonClass pvt=new SingletonClass();
	}
	
	public static SingletonClass getInstance()
	{
		return BillPugh.pvt;
	}
}

public class PrivateConstructor{
	public static void main(String args[])
	{
		
		SingletonClass c1= SingletonClass.getInstance();
		System.out.println(c1);
		SingletonClass c2=SingletonClass.getInstance();
		System.out.println(c2);

	}
}
