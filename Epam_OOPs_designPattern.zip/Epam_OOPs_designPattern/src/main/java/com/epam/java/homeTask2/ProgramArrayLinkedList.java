package com.epam.java.homeTask2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ProgramArrayLinkedList {
	
	public static void main(String[] args)
    {
		
		long start = System.nanoTime();
		ArrayList<Integer> al= new ArrayList<Integer>();
		for(int i=0;i<=10000;i++)
		{
			al.add(i);
		}
	    al.add(5, 8768);
		al.remove(50);
		long end=System.nanoTime();
		System.out.println("Time taken by ArrayList to add/remove elements "+(end-start));
		
		long start2 = System.nanoTime();

	    List<Integer> linkedList = new LinkedList<Integer>();
	    for(int i=0;i<=10000;i++)
	    {
	    	linkedList.add(i);
	    }
	    
	    linkedList.add(5, 8768);
		linkedList.remove(50);
		long end2=System.nanoTime();

		System.out.println("Time taken by LinkedList to add/remove elements "+(end2-start2));
		
		long start3 = System.nanoTime();

		for(int i=0; i < al.size(); i++) {
		      if(al.get(i).equals(1647)){
		        System.out.println("Value present at index: "+i); 
		      }
		    }
		long end3=System.nanoTime();
		System.out.println("Time taken by Array to search an element is "+(end3 - start3));

		
		long start4 = System.nanoTime();

		  for(int i=0; i < linkedList.size(); i++) {
		      if(linkedList.get(i).equals(1647)){
		        System.out.println("Value present at index: "+i); 
		      }
		    }
		 long end4=System.nanoTime();
		System.out.println("Time taken by LinkedList to search an element is "+(end4-start4));

}
}
