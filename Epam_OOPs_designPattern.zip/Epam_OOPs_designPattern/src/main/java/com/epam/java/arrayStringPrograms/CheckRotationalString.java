package com.epam.java.arrayStringPrograms;

import java.util.Scanner;

public class CheckRotationalString {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		String s1=sc.nextLine();
		String s2=sc.nextLine();
		
		if(s1.length()!=s2.length())
			System.out.println("Strings are not rotational of each other");
		else
		{
			s1=s1+s1;
			if(s1.indexOf(s2)!=-1)
			{
				System.out.println("Strings are deabc rotational of each other");

			}
			else
			{
				System.out.println("Strings are not rotational of each other");

			}
		}
	}

}
