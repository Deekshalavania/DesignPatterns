package com.epam.java.HomeTask1;

public class ButterToast extends Sweet {
	public ButterToast(String name, String type, int weight, double consSuga) {
		super(name, type, weight, consSuga);
		calculateCost();
	}

	@Override
	public void calculateCost() {

		double cost;
		if(this.getsweetweight()<100)
		{
			cost=200;
		}
		else if(this.getsweetweight()>=100 && this.getsweetweight()<=500)
		{
			cost=350.797;
		}
		else
		{
			cost=560;
		}
		this.setsweetCost(cost);

	}

	
}
