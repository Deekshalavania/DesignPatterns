package com.epam.java.homeTaskOnVariable;

public class ProgramOnFloatVar {

	public static void main(String[] args) {
		
		double danielApples=3.5;
		double amberApples=2.5;
		double total=danielApples+amberApples;
		System.out.println("Total Apples that Daniel and Amber have together are " +total);
	}
}
