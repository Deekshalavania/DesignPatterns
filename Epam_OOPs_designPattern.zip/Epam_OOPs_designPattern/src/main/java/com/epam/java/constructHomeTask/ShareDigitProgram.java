package com.epam.java.constructHomeTask;

public class ShareDigitProgram {

	public static boolean shareDigit(int a, int b)
	{
		int aDigit = a%10;
		int bDigit = b%10;
		a /= 10;
		b /= 10;
		return (a == b || a == bDigit || aDigit == b || aDigit == bDigit);
	}

	public static void main(String[] args) {
		System.out.println(shareDigit(12, 23));
		System.out.println(shareDigit(12, 43));
		System.out.println(shareDigit(12, 44));
		
	
		
	}

}
